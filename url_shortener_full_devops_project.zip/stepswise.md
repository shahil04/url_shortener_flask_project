
# URL Shortener – Full DevOps Project (Step-by-Step)

## Phase 1: Run Application Locally
- Install Python & MySQL
- Create database and table
- Run: python app.py

## Phase 2: Dockerize
- docker build -t url-shortener .
- docker run -p 5000:5000 url-shortener

## Phase 3: Docker Compose
- docker-compose up --build
- Create table inside MySQL container

## Phase 4: Kubernetes (Minikube)
- minikube start
- kubectl apply -f k8s/
- minikube service url-service

## Phase 5: AWS EKS
- Create cluster with eksctl
- Push image to Docker Hub/ECR
- Update image name
- kubectl apply -f k8s/

## Phase 6: CI/CD
- Create GitHub Actions pipeline
- Push code and auto deploy

🎉 Project Complete
